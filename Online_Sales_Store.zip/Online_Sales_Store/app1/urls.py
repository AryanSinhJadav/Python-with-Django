
from django.urls import path
from .views import *
urlpatterns = [
    path('first/',first,name='first'),
    path('demo/',demo,name='demo'),
    path('show_data/',show_data,name='show_data'),
    path('show_img/',show_img,name='show_img'),
    path('store/',store,name='store'),
    path('store_img/',store_img,name='store_img'),
    path('register/',register_user,name='register'),
    path('login/',login,name='login'),
    path('',index,name='index'),
    path('logout/',logout,name='logout'),
    path('cat_pro/<int:id>',cat_pro,name='cat_pro'),
    path('pro_details/<int:id>',pro_details,name='pro_details'),
    path('profile/',profile,name='profile'),
    path('cart_view/',cart_view,name='cart_view'),
    path('plus_item/<int:id>',plus_item,name='plus_item'),
    path('minus_item/<int:id>',minus_item,name='minus_item'),
    path('checkout/',checkout,name='checkout'),
    path('razorpay_payment/',razorpay_payment,name='razorpay_payment'),
    path('payemnt_handler/',payemnt_handler,name='payemnt_handler'),
    path('buy_checkout/',buy_checkout,name='buy_checkout'),
    path('check_otp/',check_otp,name='check_otp'),
    path('order_history/',order_history,name='order_history'),


















    
]
