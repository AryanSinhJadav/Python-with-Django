from django.db import models
from django import forms
# Create your models here.



class Student(models.Model):
    email = models.EmailField()
    name = models.CharField(max_length=50)


    def __str__(self):
        return self.email
    

class Emp(models.Model):
    name = models.CharField(max_length=50)
    mob = models.CharField(max_length=10)
    add = models.TextField()


class Img(models.Model):
    name = models.CharField(max_length=50)
    image = models.ImageField(upload_to='test_img')


class Register(models.Model):
    name = models.CharField(max_length=50)
    email = models.EmailField()
    mob = models.CharField(max_length=10)
    add = models.TextField()
    password = models.CharField(max_length=100)
    city = models.CharField(max_length=50)
    state = models.CharField(max_length=50)
    pincode = models.CharField(max_length=50)

    def __str__(self):
        return self.email
    

class Category(models.Model):
    name = models.CharField(max_length=50)
    image = models.ImageField(upload_to='test_img')
    decription = models.TextField()

    def __str__(self):
        return self.name
    
class Product(models.Model):
    name = models.CharField(max_length=50)
    image = models.ImageField(upload_to='test_img')
    decription = models.TextField()
    price = models.PositiveIntegerField()
    stock_unit = models.PositiveIntegerField()
    category = models.ForeignKey(Category,on_delete=models.CASCADE)

    def __str__(self):
        return self.name
    
class Cart(models.Model):
    user = models.ForeignKey(Register,on_delete=models.CASCADE)
    pro = models.ForeignKey(Product,on_delete=models.CASCADE)
    qty = models.PositiveIntegerField()
    total_price = models.PositiveIntegerField()
    order_id = models.PositiveIntegerField(default=0)
    in_stock = models.BooleanField(default=True)

    def __str__(self):
        return str(self.user)
    

class Order(models.Model):
    user = models.ForeignKey(Register,on_delete=models.CASCADE)
    pro = models.ForeignKey(Product,on_delete=models.CASCADE)
    qty = models.PositiveIntegerField()
    total_price = models.PositiveIntegerField()
    order_id = models.CharField(default="0")
    name = models.CharField(max_length=50)
    mob = models.CharField(max_length=10)
    add = models.TextField()
    city = models.CharField(max_length=50)
    state = models.CharField(max_length=50)
    pincode = models.CharField(max_length=50)
    dt = models.DateTimeField(auto_now=True)
    payment_type = models.CharField(max_length=50)
    transaction_id = models.CharField(max_length=100)

    def __str__(self):
        return str(self.user)