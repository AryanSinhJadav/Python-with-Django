from django.contrib import admin
from .models import *
# Register your models here.




class stu_(admin.ModelAdmin):
    list_display = ['id','name','email']

admin.site.register(Student,stu_)


class emp_(admin.ModelAdmin):
    list_display = ['id','name','mob','add']


admin.site.register(Emp,emp_)




class img_(admin.ModelAdmin):
    list_display = ['id','name','image']


admin.site.register(Img,img_)



class reg_(admin.ModelAdmin):
    list_display = ['id','name','email','add','password']


admin.site.register(Register,reg_)

class cat_(admin.ModelAdmin):
    list_display = ['id','name','image','decription']

admin.site.register(Category,cat_)


class pro_(admin.ModelAdmin):
    list_display = ['id','name','image','decription','price','stock_unit','category']

admin.site.register(Product,pro_)


class cart_(admin.ModelAdmin):
    list_display = ['id','user','pro','total_price','qty','order_id','in_stock']


admin.site.register(Cart,cart_)



class order_(admin.ModelAdmin):
    list_display = ['id','user','pro','total_price','qty','order_id','dt','payment_type','transaction_id']


admin.site.register(Order,order_)