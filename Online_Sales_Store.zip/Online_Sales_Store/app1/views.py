from django.shortcuts import render , HttpResponse , redirect
from .models import *

# Create your views here.



def first(request):
    return HttpResponse("hello world , this is my first webpage.")


def demo(request):
    return render(request,'demo.html')


def show_data(request):
    student_data = Student.objects.all()
    # print(student_data)
    # for i in student_data:
    #     print(i.id)
    return render(request,'show_data.html',{'student':student_data})


# filter - fetchs multiple data based on filter , allows multiples and does not gives error when data is empty  
# get - always fetch unique single data, geenrates error even when data is empty

def show_img(request):
    img_data = Img.objects.all()
    return render(request,'show_img.html',{'images':img_data})


def store(request):
    if request.method == 'POST':
        store_emp = Emp()
        store_emp.name = request.POST['uname']
        store_emp.mob = request.POST['umob']
        store_emp.add = request.POST['add']
        store_emp.save()
    return render(request,'store.html',{})


def store_img(request):
    if request.method == 'POST' and request.FILES:
        store_data = Img(name = request.POST['name'],
            image = request.FILES['image'])
        store_data.save()
    return render(request,'store_img.html')

from django.core.mail import send_mail
from django.core.mail.backends.smtp import EmailBackend

from django.contrib.auth.hashers import make_password , check_password

# def register_user(request):
#     if request.method == 'POST':
#         try:
#             already_reg = Register.objects.get(email = request.POST['email'])
#             if already_reg:
#                 return render(request,'register.html',{'already':"This email already exists."})
#         except:
#             encrypted_password = make_password(request.POST['password'])
#             store_data = Register(name = request.POST['name'],
#                 email = request.POST['email'],
#                 add = request.POST['add'],
#                 password =  encrypted_password ,
#                 city = request.POST['city'],
#                 state = request.POST['state'],
#                 pincode = request.POST['pin'],
#                 mob = request.POST['mob'])
#             store_data.save()
#             send_mail(
#                 "This is an authentication mail",
#                 "Thanyou for registering in out website.",
#                 'pqr6997@gmail.com',
#                 [request.POST['email']],
#                 fail_silently=False
#             )
#         return render(request,'register.html')
#     else:
#         return render(request,'register.html',{})

from .encryption_password import encryption , decryption

def register_user(request):
    if request.method == 'POST':
        try:
            already_reg = Register.objects.get(email = request.POST['email'])
            if already_reg:
                return render(request,'register.html',{'already':"This email already exists."})
        except:
            encrypted_password = encryption(request.POST['password'])
            store_data = Register(name = request.POST['name'],
                email = request.POST['email'],
                add = request.POST['add'],
                password =  encrypted_password ,
                city = request.POST['city'],
                state = request.POST['state'],
                pincode = request.POST['pin'],
                mob = request.POST['mob'])
            store_data.save()
            send_mail(
                "This is an authentication mail",
                "Thanyou for registering in out website.",
                'pqr6997@gmail.com',
                [request.POST['email']],
                fail_silently=False
            )
        return render(request,'register.html')
    else:
        return render(request,'register.html',{})

import random

# def login(request):
#     if request.method == 'POST':
#         try:
#             # otp = random.randint(1000,9999)
#             registered = Register.objects.get(email = request.POST['email'])
#             decrypted_pass = check_password(request.POST['password'],registered.password)
#             print(decrypted_pass,"decrypted_ppppppassssssss")
#             if decrypted_pass:
#             # if request.POST['password'] == registered.password:
#                 request.session['login'] = registered.email
#             #     send_mail(
#             #     "This is an authentication mail",
#             #     f"Your otp is : {otp}",
#             #     'pqr6997@gmail.com',
#             #     [request.POST['email']],
#             #     fail_silently=False
#             # )
#             #     request.session['otp'] = otp
#                 # return redirect('check_otp')
#                 return redirect('index')

#             else:
#                 return render(request,'login.html',{'wrong':'The password is incorrect'})

#         except:
#             return render(request,'login.html',{'not_exists':'you havent registered yet'})

#     return render(request,'login.html')


def login(request):
    if request.method == 'POST':
        try:
            # otp = random.randint(1000,9999)
            registered = Register.objects.get(email = request.POST['email'])
            # decrypted_pass = check_password(request.POST['password'],registered.password)
            decrypted_pass = decryption(registered.password)
            print(decrypted_pass,"decrypted_ppppppassssssss")
            # if decrypted_pass:
            if request.POST['password'] == decrypted_pass:
                request.session['login'] = registered.email
            #     send_mail(
            #     "This is an authentication mail",
            #     f"Your otp is : {otp}",
            #     'pqr6997@gmail.com',
            #     [request.POST['email']],
            #     fail_silently=False
            # )
            #     request.session['otp'] = otp
                # return redirect('check_otp')
                return redirect('index')

            else:
                return render(request,'login.html',{'wrong':'The password is incorrect'})

        except:
            return render(request,'login.html',{'not_exists':'you havent registered yet'})

    return render(request,'login.html')

def check_otp(request):
    if request.method == 'POST':
        if int(request.POST['otp']) == request.session['otp']:
            return redirect('index')
        else:
            return render(request,'check_otp.html',{'invalid':"invalid otp"})
    else:
        return render(request,'check_otp.html')


def index(request):
    cat = Category.objects.all()
    if 'login' in request.session:
        return render(request,'index.html',{'cat':cat,'logged_in':True})
    else:
        return render(request,'index.html',{'cat':cat})
    

def logout(request):
    del request.session['login']
    return redirect('index')

def profile(request):
    if 'login' in request.session:
        logged_in = Register.objects.get(email = request.session['login'])
        template = loader.get_template('profile.html')
        data = {
            'logged_in' : logged_in
        }
        if request.method == 'POST':
            logged_in.name = request.POST['name']
            logged_in.mob = request.POST['mob']
            logged_in.add = request.POST['add']
            logged_in.save()
            return HttpResponse(template.render(data,request))
        else:
            return HttpResponse(template.render(data,request)) 
    else:
        return redirect('login')
    

def cat_pro(request,id):
    pros = Product.objects.filter(category = id)
    if 'login' in request.session:
        return render(request,'cat_pro.html',{'pros':pros,'logged_in':True})
    else:
        return render(request,'cat_pro.html',{'pros':pros})


def pro_details(request,id):
    pro = Product.objects.get(id = id)
    # if request.method == 'POST':
    if 'cart' in request.POST:
        if 'login' in request.session:
            loggedin_in = Register.objects.get(email = request.session['login'])
            try:
                already_cart = Cart.objects.get(pro = pro,user = loggedin_in,order_id = 0)
                if already_cart:
                    already_cart.qty += 1
                    already_cart.total_price += pro.price
                    already_cart.save()
                    return redirect('cart_view')
            except:
                add_to_cart = Cart(user = loggedin_in,
                    pro = pro,
                    qty = 1,
                    total_price = pro.price
                    )
                add_to_cart.save()
                return render(request,'product.html',{'pro':pro,'logged_in':True})
        else:
            return redirect('login')
    elif 'buy' in request.POST:
        if 'login' in request.session:
            loggedin_in = Register.objects.get(email = request.session['login'])
            request.session['proid'] = id
            return redirect('buy_checkout')
        else:
            return redirect('login')
    else:
        if 'login' in request.session:

            return render(request,'product.html',{'pro':pro,'logged_in':True})
        else:
            return render(request,'product.html',{'pro':pro})



def buy_checkout(request):
    if 'login' in request.session:
        loggedin_in = Register.objects.get(email = request.session['login'])
        pro = Product.objects.get(id = request.session['proid'])
        a = "QWERTYUIOPASDFGHJKLZXCVBNM"
        b = "qwertyuiopasdfghjklzxcvbnm"
        c = "1234567890"
        d = random.sample(a,5) + random.sample(b,5) + random.sample(c,2)
        random.shuffle(d)
        e = ""
        e = e.join(d)
        print(e,"ooooooooorrrrrrrddddddddddeeerrrr")
        # order_id = 
        if request.method == 'POST':
            if request.POST['paymentvia'] == 'cod':
                print("post tureweeeeeeeeeeeeeeeeeeeeeeeeeeee")
                qty = request.POST['qty']
                store_order = Order(user = loggedin_in,
                    pro = pro, 
                    qty = qty,
                    total_price = int(qty) * pro.price,
                    name =  request.POST['name'],
                    mob = request.POST['mob'],
                    add = request.POST['add'],
                    city = request.POST['city'],
                    state = request.POST['state'],
                    pincode = request.POST['pincode'],
                    payment_type  = request.POST['paymentvia'],
                    transaction_id = "cod",
                    order_id = "codorder"+e)
                store_order.save()
                pro.stock_unit -= int(qty)
                pro.save()
                return redirect('index')
            else:
                request.session['buy_qty'] = request.POST['qty']
                request.session['buy_online'] = int(request.POST['qty']) * pro.price
                request.session['name'] = request.POST['name']
                request.session['mob'] = request.POST['mob']
                request.session['add'] = request.POST['add']
                request.session['city'] = request.POST['city']
                request.session['state'] = request.POST['state']
                request.session['pincode'] = request.POST['pincode']
                return redirect('razorpay_payment')
        if pro.stock_unit <= 3:
            avail_stock = range(1,pro.stock_unit + 1 )
            return render(request,'checkout.html',{'pro':pro,'avail_stock':avail_stock,'logged_in':loggedin_in})
        else:
            return render(request,'checkout.html',{'pro':pro,'logged_in':loggedin_in})
    else:
        return redirect('login')



from django.template import loader





def cart_view(request):
    if 'login' in request.session:
        changed = False
        logged_in = Register.objects.get(email = request.session['login'])
        cart_data = Cart.objects.filter(user = logged_in,order_id = 0)
        total = 0
        for i in cart_data:
            total += i.total_price
        return render(request,'cart.html',{'logged_in':True,'cart_data':cart_data,'total':total})
    else:
        return redirect('login')
        

def plus_item(request,id):
    cart_data = Cart.objects.get(id = id)
    cart_data.qty += 1
    cart_data.total_price += cart_data.pro.price
    cart_data.save()
    return redirect('cart_view')


def minus_item(request,id):
    cart_data = Cart.objects.get(id = id)
    if cart_data.qty <= 1:
        cart_data.delete()
        return redirect('cart_view')
    else:
        cart_data.qty -= 1
        cart_data.total_price -= cart_data.pro.price
        cart_data.save()
        return redirect('cart_view')

def checkout(request):
    if 'login' in request.session:
        logged_in = Register.objects.get(email = request.session['login'])
        if request.method == 'POST':
            a = "QWERTYUIOPASDFGHJKLZXCVBNM"
            b = "qwertyuiopasdfghjklzxcvbnm"
            c = "1234567890"
            d = random.sample(a,5) + random.sample(b,5) + random.sample(c,2)
            random.shuffle(d)
            e = ""
            e = e.join(d)
            print(e,"ooooooooorrrrrrrddddddddddeeerrrr")
            total = 0
            cart_data = Cart.objects.filter(user = logged_in,order_id = 0)
            for i in cart_data:
                total += i.total_price
            if request.POST['paymentvia'] == 'cod':
                cart_data = Cart.objects.filter(user = logged_in,order_id = 0)
                for i in cart_data:   
                    store_order = Order(user = logged_in,
                                        pro = i.pro, 
                                        qty = i.qty,
                                        total_price = i.total_price,
                                        name =  request.POST['name'],
                                        mob = request.POST['mob'],
                                        add = request.POST['add'],
                                        city = request.POST['city'],
                                        state = request.POST['state'],
                                        pincode = request.POST['pincode'],
                                        payment_type  = request.POST['paymentvia'],
                                        transaction_id = "cod",
                                        order_id = "codorder"+e)
                    store_order.save()
                    latest_row = Order.objects.latest('id')
                    i.order_id = latest_row.id
                    i.save()
                    pro = Product.objects.get(id = i.pro.id)
                    pro.stock_unit -= i.qty
                    pro.save()
                return redirect('index')
            else:
                request.session['name'] = request.POST['name']
                request.session['mob'] = request.POST['mob']
                request.session['add'] = request.POST['add']
                request.session['city'] = request.POST['city']
                request.session['state'] = request.POST['state']
                request.session['pincode'] = request.POST['pincode']
                request.session['amount'] = total
                return redirect('razorpay_payment')
        else:
            cart_data = Cart.objects.filter(user = logged_in,order_id = 0)
            total = 0
            for i in cart_data:
                total += i.total_price
            return render(request,'checkout.html',{'logged_in':logged_in,'cart_data':cart_data,'total':total})
    else:
        return redirect('login')


import razorpay
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponseBadRequest


razorpay_client = razorpay.Client(auth = (settings.RAZORPAY_KEY_ID , settings.RAZORPAY_KEY_SECRET))


def razorpay_payment(request):
    if 'buy_online' in request.session:
        currency = 'INR'
        amount = int(request.session['buy_online']) * 100
        razorpay_order = razorpay_client.order.create(dict(amount = amount,
                                        currency = currency,
                                        payment_capture = '0'))
        razorpay_order_id = razorpay_order['id']
        return render(request,'razorpay.html',{'razorpay_merchant_key':settings.RAZORPAY_KEY_ID,
                                            'razorpay_amount' : amount,
                                            'currency':currency,
                                            'razorpay_order_id':razorpay_order_id,
                                            'callback_url':"http://127.0.0.1:8000/payemnt_handler/"})
    else:
        currency = 'INR'
        amount = int(request.session['amount']) * 100
        razorpay_order = razorpay_client.order.create(dict(amount = amount,
                                        currency = currency,
                                        payment_capture = '0'))
        razorpay_order_id = razorpay_order['id']
        return render(request,'razorpay.html',{'razorpay_merchant_key':settings.RAZORPAY_KEY_ID,
                                            'razorpay_amount' : amount,
                                            'currency':currency,
                                            'razorpay_order_id':razorpay_order_id,
                                            'callback_url':"http://127.0.0.1:8000/payemnt_handler/"})

@csrf_exempt
def payemnt_handler(request):
    if request.method == 'POST':
        try:
            payment_id = request.POST.get('razorpay_payment_id', '')
            razorpay_order_id = request.POST.get('razorpay_order_id', '')
            signature = request.POST.get('razorpay_signature', '')

            params_dict = {
                'razorpay_payment_id' : payment_id,
                'razorpay_order_id' : razorpay_order_id,
                'razorpay_signature' : signature
            }

            result = razorpay_client.utility.verify_payment_signature(params_dict)
            logged_in = Register.objects.get(email = request.session['login'])

            if 'buy_online' in request.session:
                
                amount = int(request.session['buy_online']) * 100
                razorpay_client.payment.capture(payment_id,amount)

                print("==================== Payment ID ============================")
                print(payment_id)
                pro = Product.objects.get(id = request.session['proid'])
                store_order = Order(user = logged_in,
                    pro = pro, 
                    qty = request.session['buy_qty'],
                    total_price = request.session['buy_online'],
                    name =  request.session['name'],
                    mob = request.session['mob'],
                    add = request.session['add'],
                    city = request.session['city'],
                    state = request.session['state'],
                    pincode = request.session['pincode'],
                    payment_type  = "Online_buy",
                    transaction_id = payment_id,
                    order_id = razorpay_order_id)
                store_order.save()
                pro.stock_unit -= int(request.session['buy_qty'])
                pro.save()
                del request.session['buy_online']
                return redirect('index')
            else:
                amount = int(request.session['amount']) * 100
                razorpay_client.payment.capture(payment_id,amount)
                cart_data = Cart.objects.filter(user = logged_in,order_id = 0)
                for i in cart_data:   
                        store_order = Order(user = logged_in,
                                            pro = i.pro, 
                                            qty = i.qty,
                                            total_price = i.total_price,
                                            name =  request.session['name'],
                                            mob = request.session['mob'],
                                            add = request.session['add'],
                                            city = request.session['city'],
                                            state = request.session['state'],
                                            pincode = request.session['pincode'],
                                            payment_type  = 'online',
                                            transaction_id = payment_id,
                                            order_id = razorpay_order_id)
                        store_order.save()
                        latest_row = Order.objects.latest('id')
                        i.order_id = latest_row.id
                        i.save()
                        pro = Product.objects.get(id = i.pro.id)
                        pro.stock_unit -= i.qty
                        pro.save()
                return redirect('index')
        except Exception as e:
            print(e,"errrrrrrrrooooooooorrrrrrrrrrrr")
            return HttpResponseBadRequest()
    else:
            return HttpResponseBadRequest()


def order_history(request):
    if 'login' in request.session:
        logged_in = Register.objects.get(email = request.session['login'])
        order_data = Order.objects.filter(user = logged_in)
        return render(request,'orderhistory.html',{'order_data':order_data,"logged_in":True})
    else:
        return redirect('login')